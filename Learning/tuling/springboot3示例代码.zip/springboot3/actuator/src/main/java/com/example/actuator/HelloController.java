package actuator.src.main.java.com.example.actuator;

import io.micrometer.core.annotation.Timed;
import io.micrometer.core.instrument.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/***
 * @Author 徐庶   QQ:1092002729
 * @Slogan 致敬大师，致敬未来的你
 */
@RestController
public class HelloController {
    @GetMapping("/sayHi")
    public String sayHi(String username) throws InterruptedException {
        // 线程长请求
        Thread.sleep(5000);

        System.out.println("success");

        return "success";
    }
}
