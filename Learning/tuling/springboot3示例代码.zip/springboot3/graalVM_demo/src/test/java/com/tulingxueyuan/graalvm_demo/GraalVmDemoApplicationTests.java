package com.tulingxueyuan.graalvm_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GraalVmDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
