package com.tulingxueyuan.dao;

/**
 * @author xushu
 * @time 2020/12/22 23:03:03
 */
public interface IUserDao {
    void save();
}
